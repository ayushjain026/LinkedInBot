import React from "react";
import { useNavigate } from "react-router-dom";
import Button from "@mui/material/Button";
import { useUserContext } from "../context/UserContext";

const Header = () => {
  const navigate = useNavigate();
  const { user, logout } = useUserContext();

  return (
    <>
      {/* Fixed Header */}
      <header className="fixed top-0 left-0 w-full bg-white z-50 p-6 flex justify-between items-center">
        <h1 className="text-2xl font-bold cursor-pointer" onClick={() => (navigate('/'))}>AI Virtual Assistant</h1>
        <div className="space-x-4">
          {user ? (
            <Button
              variant="contained"
              onClick={logout}
              sx={{
                backgroundColor: "#c731cd", // Updated to the extracted color
                "&:hover": { backgroundColor: "#a855f7" }, // Lighter shade for hover
              }}
            >
              Log Out
            </Button>
          ) : (
            <>
              <Button
                variant="contained"
                onClick={() => navigate("/signup")}
                sx={{
                  backgroundColor: "#c731cd", // Updated to the extracted color
                  "&:hover": { backgroundColor: "#a855f7" }, // Lighter shade for hover
                }}
              >
                Sign Up
              </Button>
              <Button
                variant="contained"
                onClick={() => navigate("/login")}
                sx={{
                  backgroundColor: "#c731cd", // Updated to the extracted color
                  "&:hover": { backgroundColor: "#a855f7" }, // Lighter shade for hover
                }}
              >
                Log In
              </Button>
            </>
          )}
        </div>
      </header>

      {/* Padding to prevent content overlap */}
      <div className="pt-20"></div>
    </>
  );
};

export default Header;
